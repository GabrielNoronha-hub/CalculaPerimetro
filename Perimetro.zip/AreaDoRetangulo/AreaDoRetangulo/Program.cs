﻿using System;

namespace CalculaArea {
    internal class Program {
        static void Main(string[] args) {
            int opcao;

            opcao = Menu();
            switch (opcao) {  
                case 1: CalculaQuadrado(); break;
                case 2: CalculaRetangulo(); break;
                case 3: CalculaCirculo(); break;
                case 4: CalculaTriangulo(); break;
                case 5: break;
            }
        }

        public static void CalculaQuadrado() {
            int resultado, lado;
            Console.WriteLine("Entre com o valor de um dos lados: ");
            lado = RecebeValor();
            resultado = lado * lado;
            Console.WriteLine("Área do quadrado: " +  resultado + "²");
        }

        public static void CalculaRetangulo() {
            int resultado, b, h;

            Console.Write("Entre com o valor da base(b): ");
            b = RecebeValor();
            Console.Write("Entre com o valor da altura(h): ");
            h = RecebeValor();
            resultado = b * h;
            Console.WriteLine("Área do retângulo: " + resultado);
        }

        public static void CalculaCirculo() {
            int raio, raioAoQuadrado;
            double pi, resultado;
            pi = 3.14;
            Console.Write("Entre com o valor do raio(r): ");
            raio = RecebeValor();
            raioAoQuadrado = raio * raio;
            resultado = pi * raioAoQuadrado;
            Console.WriteLine("Área do retângulo: " + resultado);
        }

        public static void CalculaTriangulo() {
            int resultado, b, h, multiplica;

            Console.Write("Entre com o valor da base(b): ");
            b = RecebeValor();
            Console.Write("Entre com o valor da altura(h): ");
            h = RecebeValor();
            multiplica = b * h;
            resultado = multiplica / 2;
            Console.WriteLine("Área do Triângulo: " + resultado);
        }

        public static int RecebeValor() {
            int valor;
            valor = int.Parse(Console.ReadLine());
            return valor;
        }

        public static int Menu() {
            int opcao;
            Console.WriteLine("[1] - Calcular Área de um Quadrado");
            Console.WriteLine("[2] - Calcular Área de um Retângulo");
            Console.WriteLine("[3] - Calcular Área de um Circulo");
            Console.WriteLine("[4] - Calcular Área de um Triângulo");
            Console.WriteLine("[5] - Encerrar o programa");
            Console.Write("Informe o opção desejada: ");
            opcao = int.Parse(Console.ReadLine());
            return opcao;
        }
    }
}